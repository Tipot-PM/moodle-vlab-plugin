Local Plugin - Custom Navigation
======================

Information
-----------

This plugin displays the vlab room management menu item at the end of Navigation Menu for user with capacity.
It should be installed alone side with vLab mod plugin

Version  
-------
Moodle 3.8+


